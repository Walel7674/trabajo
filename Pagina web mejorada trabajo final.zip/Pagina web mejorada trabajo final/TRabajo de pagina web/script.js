$(document).ready(function () {
  function showAppToast(title, message) {
    $("#toast-title").html(`<i class="fa-solid fa-bell me-2"></i>${title}`);
    $("#toast-message").text(message);
    const toastEl = document.getElementById("appToast");
    if (toastEl) {
      const toast = bootstrap.Toast.getOrCreateInstance(toastEl);
      toast.show();
    }
  }

  let tasks = [];
  try {
    tasks = JSON.parse(localStorage.getItem("usmp_tasks")) || [
      { text: "Revisar guía de laboratorio de Algoritmos", completed: false },
      { text: "Avanzar proyecto de Desarrollo Web", completed: false },
      { text: "Reunión del Capítulo Estudiantil IEEE", completed: false },
    ];
  } catch (e) {
    tasks = [
      { text: "Revisar guía de laboratorio de Algoritmos", completed: false },
      { text: "Avanzar proyecto de Desarrollo Web", completed: false },
    ];
  }

  function saveTasks() {
    try {
      localStorage.setItem("usmp_tasks", JSON.stringify(tasks));
    } catch (e) {
      console.error("Error guardando tareas en localStorage", e);
    }
  }

  function renderTasks() {
    $("#task-list").empty();
    tasks.forEach((task, index) => {
      const $li = $(`
                <li class="list-group-item bg-dark text-white border-secondary d-flex justify-content-between align-items-center task-item py-2 ${
                  task.completed ? "completed" : ""
                }">
                    <span><i class="fa-regular ${
                      task.completed
                        ? "fa-circle-check text-success"
                        : "fa-circle-check text-danger"
                    } me-2"></i>${task.text}</span>
                    <div>
                        <button class="btn btn-sm ${
                          task.completed ? "btn-success" : "btn-outline-success"
                        } me-1 complete-btn" data-index="${index}" title="Completar tarea" type="button">
                            <i class="fa-solid fa-check"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger delete-btn" data-index="${index}" title="Eliminar tarea" type="button">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </li>
            `);
      $("#task-list").append($li);
    });
  }

  renderTasks();

  $("#task-form").on("submit", function (e) {
    e.preventDefault();
    const taskText = $("#task-input").val().trim();
    if (taskText !== "") {
      tasks.push({ text: taskText, completed: false });
      saveTasks();
      renderTasks();
      $("#task-input").val("");
      showAppToast(
        "Tarea Agregada",
        "Se añadió el pendiente correctamente a tu lista."
      );
    }
  });

  $(document).on("click", ".complete-btn", function () {
    const index = $(this).data("index");
    if (tasks[index] !== undefined) {
      tasks[index].completed = !tasks[index].completed;
      saveTasks();
      renderTasks();
    }
  });

  $(document).on("click", ".delete-btn", function () {
    const index = $(this).data("index");
    if (tasks[index] !== undefined) {
      tasks.splice(index, 1);
      saveTasks();
      renderTasks();
    }
  });

  let courses = [];
  try {
    courses = JSON.parse(localStorage.getItem("usmp_courses")) || [
      { name: "Algoritmos", grade: 17, credits: 4 },
      { name: "Circuitos Digitales", grade: 16, credits: 3 },
    ];
  } catch (e) {
    courses = [{ name: "Algoritmos", grade: 17, credits: 4 }];
  }

  function saveCourses() {
    try {
      localStorage.setItem("usmp_courses", JSON.stringify(courses));
    } catch (e) {
      console.error("Error guardando cursos en localStorage", e);
    }
  }

  function renderCourses() {
    const $tbody = $("#calc-table tbody");
    $tbody.empty();

    let totalPoints = 0;
    let totalCredits = 0;

    courses.forEach((course, index) => {
      totalPoints += course.grade * course.credits;
      totalCredits += course.credits;

      const badgeClass = course.grade >= 11 ? "bg-success" : "bg-danger";
      const $row = $(`
                <tr>
                    <td>${course.name}</td>
                    <td><span class="badge ${badgeClass}">${course.grade.toFixed(
        1
      )}</span></td>
                    <td>${course.credits}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-danger remove-course" data-index="${index}" title="Eliminar curso" type="button">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </td>
                </tr>
            `);
      $tbody.append($row);
    });

    const gpa =
      totalCredits > 0 ? (totalPoints / totalCredits).toFixed(2) : "0.00";
    $("#final-gpa").text(gpa);
    saveCourses();
  }

  renderCourses();

  $("#calc-form").on("submit", function (e) {
    e.preventDefault();
    const name = $("#course-name").val().trim();
    const grade = parseFloat($("#course-grade").val());
    const credits = parseInt($("#course-credits").val());

    if (name && !isNaN(grade) && !isNaN(credits)) {
      courses.push({ name, grade, credits });
      renderCourses();
      $("#course-name").val("");
      $("#course-grade").val("");
      $("#course-credits").val("");
      showAppToast(
        "Curso Registrado",
        `Se añadió "${name}" a tu cálculo de promedio.`
      );
    }
  });

  $(document).on("click", ".remove-course", function () {
    const index = $(this).data("index");
    if (courses[index] !== undefined) {
      courses.splice(index, 1);
      renderCourses();
    }
  });

  let pomoInterval = null;
  let pomoTimeLeft = 25 * 60;
  let isPomoRunning = false;

  function updatePomoDisplay() {
    const minutes = Math.floor(pomoTimeLeft / 60);
    const seconds = pomoTimeLeft % 60;
    $("#pomodoro-timer").text(
      `${minutes.toString().padStart(2, "0")}:${seconds
        .toString()
        .padStart(2, "0")}`
    );
  }

  $("#toggle-pomodoro-btn").on("click", function () {
    $("#task-view").addClass("d-none");
    $("#pomodoro-view").removeClass("d-none");
  });

  $("#back-to-tasks").on("click", function () {
    $("#pomodoro-view").addClass("d-none");
    $("#task-view").removeClass("d-none");
  });

  $("#pomo-start").on("click", function () {
    if (!isPomoRunning) {
      isPomoRunning = true;
      $("#pomodoro-status").text("¡Sesión activa! Mantén el enfoque");
      pomoInterval = setInterval(() => {
        if (pomoTimeLeft > 0) {
          pomoTimeLeft--;
          updatePomoDisplay();
        } else {
          clearInterval(pomoInterval);
          isPomoRunning = false;
          showAppToast(
            "¡Pomodoro Finalizado!",
            "¡Bloque completado con éxito! Tómate un descanso de 5 minutos."
          );
          pomoTimeLeft = 25 * 60;
          updatePomoDisplay();
          $("#pomodoro-status").text("Bloque de estudio concentrado (25 min)");
        }
      }, 1000);
    }
  });

  $("#pomo-pause").on("click", function () {
    clearInterval(pomoInterval);
    isPomoRunning = false;
    $("#pomodoro-status").text("Temporizador pausado");
  });

  $("#pomo-reset").on("click", function () {
    clearInterval(pomoInterval);
    isPomoRunning = false;
    pomoTimeLeft = 25 * 60;
    updatePomoDisplay();
    $("#pomodoro-status").text("Bloque de estudio concentrado (25 min)");
  });

  $(".filter-btn").on("click", function () {
    $(".filter-btn").removeClass("active");
    $(this).addClass("active");

    const filter = $(this).data("filter");
    if (filter === "all") {
      $(".filter-item").fadeIn(300);
    } else {
      $(".filter-item").hide();
      $(`.filter-item.${filter}`).fadeIn(300);
    }
  });

  $(".btn-event").on("click", function () {
    const eventName = $(this).data("event");
    showAppToast(
      "Inscripción Exitosa",
      `Te has registrado correctamente en: "${eventName}". ¡Te esperamos!`
    );
  });

  let animatedStats = false;
  $(window).on("scroll", function () {
    const statsSection = $(".stat-number");
    if (statsSection.length && !animatedStats) {
      const hT = statsSection.offset().top,
        hH = statsSection.outerHeight(),
        wH = $(window).height(),
        wS = $(this).scrollTop();
      if (wS > hT + hH - wH) {
        animatedStats = true;
        $(".stat-number").each(function () {
          const $this = $(this);
          const target = parseInt($this.data("target")) || 0;
          const suffix = $this.data("suffix") || "";

          $({ Counter: 0 }).animate(
            { Counter: target },
            {
              duration: 1500,
              easing: "swing",
              step: function () {
                $this.text("+" + Math.ceil(this.Counter) + suffix);
              },
            }
          );
        });
      }
    }
  });

  $(".navbar-nav a, .hero-section a").on("click", function (e) {
    if (this.hash !== "") {
      e.preventDefault();
      const hash = this.hash;
      const $target = $(hash);
      if ($target.length) {
        $("html, body").animate(
          {
            scrollTop: $target.offset().top - 75,
          },
          600
        );
        $(".navbar-collapse").collapse("hide");
      }
    }
  });
});
